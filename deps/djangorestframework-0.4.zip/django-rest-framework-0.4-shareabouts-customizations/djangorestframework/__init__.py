__version__ = '0.4.0-dev'

VERSION = __version__  # synonym
