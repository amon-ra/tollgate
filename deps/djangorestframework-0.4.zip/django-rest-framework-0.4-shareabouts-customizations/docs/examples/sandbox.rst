Sandbox Root API
================

The Resource
------------

The root level resource of the Django REST framework examples is a simple read only resource:

``view.py``

.. include:: ../../examples/sandbox/views.py
    :literal:
