:mod:`compat`
=====================

.. automodule:: compat
   :members:
