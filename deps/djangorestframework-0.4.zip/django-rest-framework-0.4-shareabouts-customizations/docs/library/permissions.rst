:mod:`permissions`
=====================

.. automodule:: permissions
   :members:
