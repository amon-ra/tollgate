:mod:`mixins`
=====================

.. automodule:: mixins
   :members:
