:mod:`resource` 
===============

.. automodule:: resources
   :members:
