#We need models.py otherwise the test framework complains (http://code.djangoproject.com/ticket/7198)
